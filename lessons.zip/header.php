<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header"><a class="navbar-brand navbar-link" href="#">Hackaton </a>
            <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        </div>
        <div class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav navbar-right">
                <li role="presentation"><a href="..">Accueil </a></li>
                <li role="presentation"><a href="../lessons">Leçons </a></li>
                <li role="presentation"><a href="../medias">Médias </a></li>
                <li class="active" role="presentation"><a href="../jeux">jeux </a></li>
                <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">Octimus Prime<span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li role="presentation"><a href="#">Mon Profile </a></li>
                        <li role="presentation"><a href="#">Déconnexion </a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>