
#Pendu

Jeu du Pendu

Le pendu est jeu qui se joue généralement à deux et où l'adversaire doit trouver le mot caché en devinant les lettres qui le composent.

Le jeu a été principalement créé en Javascipt/JQuery.

Les seules dépendances sont le Framework JQuery et Twitter Bootstrap (css et js).

