
var oygCrosswordPuzzle = new oyCrosswordPuzzle (
"9338393004",
"./JCE",
"/a/a",
"Mots croisés",
"Lexique de la dictée 64",
[
new oyCrosswordClue(6,"Manger de l'herbe.","PAITRE","32b87162b5d34c0c371cc26ebcaf1655",1,12,9)
,new oyCrosswordClue(7,"Ornement du cou.","COLLIER","c6260b7190f87a68a1dd34c687420da4",1,16,8)
,new oyCrosswordClue(5,"Qui a perdu son chemin.","EGARE","b91976e996a269f389e7c785ea976bb6",1,8,13)
,new oyCrosswordClue(8,"Il est allaité par la chèvre.","CHEVREAU","ddb9fafcd4b3419cdad903b9df17f0a7",1,5,8)
,new oyCrosswordClue(7,"Messagère de paix.","COLOMBE","82f3fa357e5ad5da3107a6db39de5e3b",1,2,4)
,new oyCrosswordClue(6,"Femelle du mouton.","BREBIS","f6ab4f2e669219b07c6ea2584d3753ff",0,8,11)
,new oyCrosswordClue(9,"Celui avec qui on partage son pain et davantage...","COMPAGNON","518ad353ab5a315d8d82484db9e3ffcc",0,9,9)
,new oyCrosswordClue(7,"Maison.","DEMEURE","0a9e4a3beb587bc434bfca7dfa467f38",0,7,13)
,new oyCrosswordClue(8,"Bétail.","TROUPEAU","7b4fc034e8687bcbf08106580b7ac56a",0,2,15)
,new oyCrosswordClue(6,"Il garde le troupeau.","BERGER","fddc05e9784f624fa685e841a959c73b",0,1,10)
],
20,20);

oygCrosswordPuzzle.publisherName = "Patrick Cardona";
oygCrosswordPuzzle.leaveGameURL = "./licence.html";
oygCrosswordPuzzle.canTalkToServer = false;
